package com.newjazz.app;
import android.app.Activity;import android.os.Bundle;import android.view.View;import android.webkit.WebSettings;import android.webkit.WebView;import android.webkit.WebViewClient;import android.content.Intent;import android.net.Uri;
public class MainActivity extends Activity{
 WebView w;
 @Override protected void onCreate(Bundle b){super.onCreate(b);
  w=new WebView(this);setContentView(w);
  WebSettings s=w.getSettings();s.setJavaScriptEnabled(true);s.setDomStorageEnabled(true);s.setAllowFileAccess(true);s.setAllowFileAccessFromFileURLs(true);s.setAllowUniversalAccessFromFileURLs(true);s.setMediaPlaybackRequiresUserGesture(false);
  w.setWebViewClient(new WebViewClient(){@Override public boolean shouldOverrideUrlLoading(WebView v,String u){if(u.startsWith("http")){startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(u)));return true;}return false;}});
  w.setBackgroundColor(0xFF07091A);w.loadUrl("file:///android_asset/www/index.html");hide();}
 void hide(){getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN|View.SYSTEM_UI_FLAG_HIDE_NAVIGATION|View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY|View.SYSTEM_UI_FLAG_LAYOUT_FULL_SCREEN);}
 @Override public void onWindowFocusChanged(boolean f){super.onWindowFocusChanged(f);if(f)hide();}
 @Override protected void onPause(){super.onPause();w.onPause();}
 @Override protected void onResume(){super.onResume();w.onResume();}
}
