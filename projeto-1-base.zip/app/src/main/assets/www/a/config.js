window.NJ_SERVER='wss://servidor-newjazz.onrender.com';
